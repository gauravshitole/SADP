package Que6;

public interface Command {
    public void execute();
}
