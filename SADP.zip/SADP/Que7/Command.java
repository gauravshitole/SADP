package SADP.Que7;

public interface Command {
    public void execute();
}
