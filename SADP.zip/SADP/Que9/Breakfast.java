package SADP.Que9;

import java.text.BreakIterator;

interface Iterator{
    public boolean hasNext();
    public Object next();

}
 interface Menu{
    public Iterator getMenu();
 }

public class Breakfast implements Menu {
    public String names[]={"Vadapav", "Misal","Dosa"};
    
    public Iterator getMenu()
    {
        return new BreakfastIter();
    }
    
    private class BreakfastIter implements Iterator
    {
        int index;
        public boolean hasNext()
        {
            if(index<names.length)
            {
                return true;
            }
            return false;
        }

        public Object next()
        {
            if(this.hasNext())
            {
                return names[index++];

            }
            return null;
        }
    } 
}

// public class BreakfastMenu {
//     public static void main(String[] args) {
//         BreakfastIter breakfastiter=new BreakfastIter();
//         for(Iterator iter=breakfastiter.getMenu();iter.hasNext();)
//         {
//             String namefast=(String)iter.next();
//             System.out.println("Breakfast Menu\n "+namefast);
//         }
//     }
// }