package Que8;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class EnumerationToIteratorAdapter<T> implements Iterator<T> {

    private final Enumeration<T> enumeration;

    public EnumerationToIteratorAdapter(Enumeration<T> enumeration) {
        this.enumeration = enumeration;
    }

    @Override
    public boolean hasNext() {
        return enumeration.hasMoreElements();
    }

    @Override
    public T next() {
        if (hasNext()) {
            return enumeration.nextElement();
        } else {
            throw new NoSuchElementException("No more elements in the enumeration.");
        }
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("remove() method is not supported.");
    }
}

