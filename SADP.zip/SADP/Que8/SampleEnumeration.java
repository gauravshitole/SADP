package Que8;

import java.util.Enumeration;
import java.util.Vector;

public class SampleEnumeration {
    public static void main(String[] args) {
        Vector<String> vector = new Vector<>();
        vector.add("Item 1");
        vector.add("Item 2");
        vector.add("Item 3");

        Enumeration<String> enumeration = vector.elements();

        // Using the Enumeration
        System.out.println("Enumeration Example:");
        while (enumeration.hasMoreElements()) {
            System.out.println(enumeration.nextElement());
        }

        // Now, let's create an adapter to use Enumeration like an Iterator
        EnumerationToIteratorAdapter<String> iteratorAdapter = new EnumerationToIteratorAdapter<>(enumeration);

        // Using the adapted Enumeration as an Iterator
        System.out.println("\nIterator Example (using Enumeration with Adapter):");
        while (iteratorAdapter.hasNext()) {
            System.out.println(iteratorAdapter.next());
        }
    }
}
